# AI4L-Collision-Avoidance
This repository contains code, documentation, and sample datasets for the AI4L airborne collision avoidance system. The project integrates radar, camera, IMU, GPS data and algorithms for real-time object detection, sensor fusion, and autonomous UAV response.
# Changelog
## [Version 1.0] - 2025-04-03
### Features
- Add suport for industrial camera with usb3.0 interface, [Alvium 1800 U-500c](https://www.alliedvision.com/en/products/alvium-configurator/alvium-1800-u/500/#_configurator)
- Support 2D Radar
- Add timestamps to imu/gps/frames
### Bug Fixes
- fix the issue that GPS no elevation info
### Known Issues
- no video recording file
## [Version 2.0] - 2025-04-xx
### Features
- Add suport for 3d radar
