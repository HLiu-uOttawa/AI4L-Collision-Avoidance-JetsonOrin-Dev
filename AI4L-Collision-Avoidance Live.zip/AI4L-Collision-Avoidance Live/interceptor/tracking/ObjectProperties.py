class ObjectProperties():
    def __init__(self):
        # Distances in meters
        self.width = 1
        self.height = 1