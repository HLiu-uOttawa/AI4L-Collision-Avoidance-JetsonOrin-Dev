# RadarDevKit

This module is the developer toolkit (slightly reorganized) to allow interacting with the IMST FMCW radar.

Please use the RadarModule class to connect to the radar and get the corresponding FD, or TD signal back.