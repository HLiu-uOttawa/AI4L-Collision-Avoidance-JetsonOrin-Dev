# UAV Target Tracking Experiment

These codes are a fork from repository: [UAV-Object-Tracking](https://github.com/nathanbowness/UAV-Object-Tracking)
, with added support for IMU, GPS, docker-compose, config, etc., for use in real experimental environments.

1. requirements.txt
   - pyserial==3.5
   - pynmea2==1.19.0
2. Docker compose
   - Build
   - Jetson Orin
3. Sensors update
   - IMU: command lines, data
   - GPS: command lines, data
4. Folder workspace
   - create workspace folder
   - imu/gps/radar/video mapping
   - configeration folder mapping
5. configeration
   - Change radar IP from 10.0.0.59 to 192.168.0.2 in RadarConfiguration.py
   - COPY ./configuration $PROJECT_PATH/configuration in file "Dockerfile-jetson-jetpack5"
   - Change radar config from "/configuration/RadarConfig.yaml" to "./configuration/RadarConfig.yaml"
   - Change video config from 'videoSource': "", to 'videoSource': "0" in file 'VideoConfiguration.py'
6. output folder
   


## Docker Buildx (on Windows 11)
Using 'buildx' to build a Docker image for the ARM64 architecture (suitable for the NVIDIA Jetson Orin) using a custom Dockerfile named Dockerfile-jetson-jetpack5. The resulting image is tagged as Object-Tracking-Experiment:latest.
```
docker buildx build --platform linux/arm64 -f Dockerfile-jetson-jetpack5 -t uav-ai4l-collision-avoidance:latest .
```
* tag
```
docker tag uav-ai4l-collision-avoidance:latest tmetal/uav-ai4l-collision-avoidance:latest
```
* push
```
docker push tmetal/uav-ai4l-collision-avoidance:latest
```

## Pull the image from NVIDIA Jetson Orin
```
sudo docker pull tmetal/uav-ai4l-collision-avoidance:latest
```
* Create a Docker container, run and attach <span style="color:red">ca88539eda1e</span>
```
sudo docker run -it tmetal/uav-ai4l-collision-avoidance:latest
sudo docker attach ca88539eda1e
```
* Run inside container
```
python3 tracking.py
```

## Check devices are available?
1. IMU - wit-motion - IMC42605 - /dev/ttyUSB0
2. GPS - /dev/ttyACM0
```
nvidia@nvidia-desktop:~/workspace$ ll /dev/ttyUSB0 
crw-rw---- 1 root dialout 188, 0 Dec 16 20:59 /dev/ttyUSB0
nvidia@nvidia-desktop:~/workspace$ ll /dev/ttyACM0 
crw-rw---- 1 root dialout 166, 0 Dec 16 20:59 /dev/ttyACM0
nvidia@nvidia-desktop:~/workspace$ ll /dev/video
video0  video1  
nvidia@nvidia-desktop:~/workspace$ ll /dev/video

```
## Docker compose
```
sudo docker-compose up -d
```
```
# version: '3.8'
  
services:
  object_detection:
    image: tmetal/object-tracking-experiment:latest
    runtime: nvidia
    devices:
      - "/dev/ttyUSB0:/dev/ttyUSB0" 
      - "/dev/ttyACM0:/dev/ttyACM0"
      - "/dev/video0:/dev/video0"
    volumes:
      - ./input:/input/
      - ./output/imu_data:/workspace/UAV-Object-Tracking/imu/imu_data/
      - ./output/gps_data:/workspace/UAV-Object-Tracking/gps/gps_data/
      - ./output:/output/
      - ./configuration:/configuration/
      - /etc/localtime:/etc/localtime:ro
      - /etc/timezone:/etc/timezone:ro
    environment:
      - TZ=America/Toronto # Ottawa Timezone
    stdin_open: true
    tty: true

```

```mermaid
graph TD
    Internet[☁️ Internet] <-->|5G| Phone[Phone 1]
    Phone[Phone] <--> |Hotspot|Router
    Router[Router<br><192.168.20.1>] <-->|BPrivate Wi-Fi 2.4G| Jetson[Jetson Board<br><192.168.20.221>]
    Router <-->|BPrivate Wi-Fi 2.4G| Phone1[Phone<br>App Tether]
    Router <-->|BPrivate Wi-Fi 5G| Laptop[Laptop<br><192.168.20.46>]
```
