SPEED_LIGHT = 299792458  # Speed of light in m/s
DIST_BETWEEN_ANTENNAS = 0.00625 # Distance between recievers of radar

RADAR_DETECTION_TYPE = "radar"
IMAGE_DETECTION_TYPE = "image" 