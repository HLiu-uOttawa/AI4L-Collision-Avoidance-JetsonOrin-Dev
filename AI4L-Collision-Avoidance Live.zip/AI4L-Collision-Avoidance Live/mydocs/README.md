#
pip install mkdocs

# 
mkdocs serve
