# Build

## Docker Build/Buildx
The following steps only verified on Windows 11
1. Start "docker desktop" on Windows
2. use terminal and go to interceptor folder
3. Using 'buildx' to build a Docker image for the ARM64 architecture (suitable for the NVIDIA Jetson Orin) using a custom
Dockerfile named Dockerfile-jetson-jetpack5. The resulting image is tagged as Object-Tracking-Experiment:latest.

* build

Build an image running on NVIDIA Jetson xavier/nx with the arm64 architecture:
```dash
docker buildx build --platform linux/arm64 `
    -f Dockerfile-jetson-jetpack5 `
    -t ai4l-collision-avoidance-arm64:latest `
    .
docker tag ai4l-collision-avoidance-arm64:latest `
    tmetal/ai4l-collision-avoidance-arm64:latest
docker push tmetal/ai4l-collision-avoidance-arm64:latest
```
Build an image running on Ubuntu with the amd64 architecture:
```dash
docker build -f Dockerfile -t ai4l-collision-avoidance-amd64:latest .
```

* tag
```
docker tag ai4l-collision-avoidance-arm64:latest tmetal/ai4l-collision-avoidance-arm64:latest
```
```
docker tag ai4l-collision-avoidance-amd64:latest tmetal/ai4l-collision-avoidance-amd64:latest
```
* push

```
docker push tmetal/ai4l-collision-avoidance-arm64:latest
```
```
docker push tmetal/ai4l-collision-avoidance-amd64:latest
```
## Run on Jetson Xavier/Orin with arm64
Pull the image from NVIDIA Jetson Orin
```
sudo docker pull tmetal/ai4l-collision-avoidance-arm64:latest
```
* Create a Docker container, run and attach container
```
docker compose up -d
```
```
docker attach 
```
* Run inside container
```
python3 tracking.py
```

## Run on Ubuntu with amd64
Pull the image
```
sudo docker pull tmetal/ai4l-collision-avoidance-amd64:latest
```
* Create a Docker container, run and attach container
```
docker compose up -d
```
* Run inside container
``` 
python3 tracking.py
```