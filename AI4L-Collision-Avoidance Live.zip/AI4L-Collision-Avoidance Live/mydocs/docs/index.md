# Welcome to AI4L Collision Avoidance Project
The repo is for Collision Avoidance of AI4L

## Project layout

    ConfigOnHost    # The configuration file.
    interceptor/
        index.md    # 
        ...         # 
    
    mydocs/         # The project documents
## Reference
* [AI4L Development Plan Ver 2.docx](attachments/AI4L Development Plan Ver 2.docx)
* [Collision avoidance experiments 2024_4.docx](attachments/Collision avoidance experiments 2024_4.docx)