# Setup of Experiment

## Connection

## Virtual Camera
install drivers/packages

```dash
sudo apt update
sudo apt install v4l2loopback-dkms
pip3 install pyfakewebcam
```
```dash
sudo modprobe v4l2loopback devices=1 video_nr=2 card_label="VirtualCam"
```

* modprobe v4l2loopback: Loads the v4l2loopback kernel module, which enables the creation of virtual video devices.
* devices=1: Specifies the creation of one virtual video device.
* video_nr=2: Assigns the virtual device to /dev/video2.
* card_label="VirtualCam": Sets the device’s label to "VirtualCam", which can be displayed by applications that list
  available video sources.

```dash
nvidia@orin-nx:~/workspace/CollisionAvoidance$ python3 stream_to_virtual_cam.py
Camera resolution: 864 x 648
Streaming started. Press ESC in preview window to stop.
Initializing /dev/video2 with size 864x648

```
##  
```dash
docker compose up -d
docker container ls -a
docker attach ai4l-collision-avoidance-arm64
```

## In container
```dash
python3 tracking.py
```
